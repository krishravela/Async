﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncAwait
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void slowButton_Click(object sender, EventArgs e)
        {
            BlockThread();
            MessageBox.Show("Came out of sleep!!! Now responding");
        }

        public void BlockThread()
        {
            Thread.Sleep(5000);
        }

        private async void fastButton_Click(object sender, EventArgs e)
        {
            await NonBlockingThread();
            MessageBox.Show("Came out of sleep!!!");
        }

        public async Task NonBlockingThread()
        {
            await Task.Run(()=>Thread.Sleep(5000));
        }

        public async Task NonWaitingThread()
        {
            Task.Run(() => Thread.Sleep(5000));
        }


        private async void superFastButton_Click(object sender, EventArgs e)
        {
            await NonWaitingThread();
            MessageBox.Show("Came out of sleep!!!");
        }
    }
}
