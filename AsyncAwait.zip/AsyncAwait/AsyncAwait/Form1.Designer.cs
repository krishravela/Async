﻿namespace AsyncAwait
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.slowButton = new System.Windows.Forms.Button();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.fastButton = new System.Windows.Forms.Button();
            this.superFastButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // slowButton
            // 
            this.slowButton.Location = new System.Drawing.Point(138, 120);
            this.slowButton.Name = "slowButton";
            this.slowButton.Size = new System.Drawing.Size(75, 23);
            this.slowButton.TabIndex = 0;
            this.slowButton.Text = "This is slow operation";
            this.slowButton.UseVisualStyleBackColor = true;
            this.slowButton.Click += new System.EventHandler(this.slowButton_Click);
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(774, 9);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 432);
            this.vScrollBar1.TabIndex = 1;
            // 
            // fastButton
            // 
            this.fastButton.Location = new System.Drawing.Point(253, 119);
            this.fastButton.Name = "fastButton";
            this.fastButton.Size = new System.Drawing.Size(75, 23);
            this.fastButton.TabIndex = 2;
            this.fastButton.Text = "This is Fast button";
            this.fastButton.UseVisualStyleBackColor = true;
            this.fastButton.Click += new System.EventHandler(this.fastButton_Click);
            // 
            // superFastButton
            // 
            this.superFastButton.Location = new System.Drawing.Point(354, 118);
            this.superFastButton.Name = "superFastButton";
            this.superFastButton.Size = new System.Drawing.Size(75, 23);
            this.superFastButton.TabIndex = 3;
            this.superFastButton.Text = "Super Fast";
            this.superFastButton.UseVisualStyleBackColor = true;
            this.superFastButton.Click += new System.EventHandler(this.superFastButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.superFastButton);
            this.Controls.Add(this.fastButton);
            this.Controls.Add(this.vScrollBar1);
            this.Controls.Add(this.slowButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button slowButton;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.Button fastButton;
        private System.Windows.Forms.Button superFastButton;
    }
}

